<?php
header("Location: /C2CeCommerceWebsite/eLogin.php"); //Redirects to the login page
exit();
?>