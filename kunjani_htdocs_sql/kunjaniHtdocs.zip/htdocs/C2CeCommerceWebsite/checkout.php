<?php
session_start();
require 'dbConnection.php';

$email = $_SESSION['email'] ?? null;    //Source https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce
if (!$email) {
    header('Location: eLogin.php');
    exit();
}

//Get cart items and total 
$buyer_id = null;

//Get buyer_id
$stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {        //Source https://www.php.net/manual/en/mysqli-result.fetch-assoc.php
    $buyer_id = $row['buyer_id'];
} else {
    //Redirect if buyer not found
    header('Location: cart.php');
    exit();
}
$stmt->close();

//Get cart items (Joins products, sellers and users)
$stmt = $conn->prepare("SELECT p.product_id, p.name, p.price, p.seller_id, 
    CONCAT(u.fname, ' ', u.lname) AS seller_name FROM cart c
    JOIN products p ON c.product_id = p.product_id
    JOIN sellers s ON p.seller_id = s.seller_id
    JOIN users u ON s.user_id = u.email WHERE c.buyer_id = ?");
$stmt->bind_param("i", $buyer_id);
$stmt->execute();
$cart_items = $stmt->get_result();

//Calculate total based on cart items added
$total = 0;
while ($item = $cart_items->fetch_assoc()) {    //Iterate through array
    $total += $item['price'];
}
$stmt->close();

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

</head>

<body>
    <!-- Navigation bar-->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <ul>
                <li><a href="welcome.php">Buy</a></li>
                <li><a href="sell.php">Sell</a></li>
                <li><a href="order.php">Orders</a></li>
            </ul>
            <span class="separator">|</span>
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                    <li><a href="cart.php" class="active"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <div class="payment-container">
            <h1 class="payment-header">Complete Your Purchase</h1>

            <div class="order-summary">
                <h3>Order Summary</h3>
                <!--Number format to store as currency-->
                <p>Total Amount: <strong>R<?= number_format($total, 2) ?></strong></p>
            </div>

            <h3>Payment Method</h3>
            <div class="payment-method selected" onclick="selectPayment(this)">
                <h4><i class="far fa-credit-card"></i> Credit/Debit Card</h4>
                <div class="payment-details" style="display: block;">
                    <div class="fake-card"> <!--Fake card info for demo purposese-->
                        <label for="Card number">Card Number:</label>
                        <input type="text" placeholder="Card Number" value="9784 1605 1243 1254" readonly>
                        <label for="Card number">Name on Card:</label>
                        <input type="text" placeholder="Name on Card" value="Fake User" readonly>
                        <div style="display: flex; gap: 15px;"> <!--Display next to each other-->
                            <label for="Card number">Expiry date:</label>
                            <input type="text" placeholder="MM/YY" value="12/25" readonly style="flex: 1;">
                            <label for="Card number">CVV:</label>
                            <input type="text" placeholder="Fake CVV" value="CVV" readonly style="flex: 1;">
                        </div>
                    </div>
                </div>
            </div>

            <button class="pay-btn" onclick="processPayment()">
                <i class="fas fa-lock"></i> Pay R<?= number_format($total, 2) ?>
            </button>
        </div>
    </main>


    <footer>
        <div class="footer-content">
            <div class="column">
                <img class="logo" src="images/Kunji.png" alt="Kunjani Logo">
            </div>

            <div class="column">
                <h4>Contact</h4>
                <p><strong>Address:</strong> 64 Edward Road, Tygervalley, Cape Town</p>
                <p><strong>Phone:</strong> (+27) 021 445 9782</p>
                <p><strong>Hours:</strong> 09:00 - 17:00, Mon - Sat</p>
            </div>

            <div class="column">
                <h4>About</h4>
                <a href="#">About Kunjani</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
                <a href="#">Help</a>
            </div>

            <div class="column">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
                <div class="Payment-methods">
                    <p>Secured Payment Gateways</p>
                    <img src="images/pay/pay.png" alt="Payment methods">
                </div>

            </div>
        </div>

        <div class="copyright">
            <p>&copy; 2025 Kunjani - eCommerce by Mathew. All Rights Reserved.</p>
        </div>
    </footer>

    <script>        
        function selectPayment(element) {
            //UI for selecting payment
            document.querySelectorAll('.payment-method').forEach(el => {
                el.classList.remove('selected');
                el.querySelector('.payment-details').style.display = 'none';
            });
            element.classList.add('selected');
            element.querySelector('.payment-details').style.display = 'block';
        }

        //Simulated payment and order processing
        function processPayment() {
            //Show success message
            alert('Payment successful! Your order has been placed.');   //Future API integration

            //Submit form to create order with POST request ( https://developer.mozilla.org/en-US/docs/Web/API/Document/createElement)
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'createOrder.php';

            //Append form to document ot be submitted
            document.body.appendChild(form);
            form.submit();  //Submit form (https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/submit)
        }
    </script>
</body>

</html>