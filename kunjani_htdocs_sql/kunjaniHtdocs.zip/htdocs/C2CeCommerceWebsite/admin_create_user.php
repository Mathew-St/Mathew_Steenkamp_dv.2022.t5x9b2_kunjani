<?php
//Show errors (https://www.php.net/manual/en/function.error-reporting.php)
error_reporting(E_ALL); //Enables all error types to be reported
ini_set('display_errors', 1);   //Displays on page

//Start session and connect to DB
session_start();
require 'dbConnection.php';

//Validate POST request form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);    //Hash the password (https://www.php.net/manual/en/function.password-hash.php)

    //Check if user already exists (duplicates)
    $check = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    //Email present (exists)
    if ($check->num_rows > 0) {
        //Duplicate email - redirect with error
        header("Location: eAdmin.php?error=duplicate");
        exit;

    //Email not present (doesn't exist)
    } else {
        //Add new user
        $stmt = $conn->prepare("INSERT INTO users (fname, lname, email, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $email, $password);
        $stmt->execute();
        $stmt->close();

        //Redirect back to admin page
        header("Location: eAdmin.php");
        exit;
    }

    $check->close();
}
?>




