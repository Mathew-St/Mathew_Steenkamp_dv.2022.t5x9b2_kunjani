<?php
require 'dbConnection.php';

//Check if email is present in URL
if (!isset($_GET['email']) || empty($_GET['email'])) {
    die("No email provided.");
}

//Assign the email from URL parameter
$email = $_GET['email'];


//Find users by email
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

//If user not found, stop execution
if (!$user) {
    die("User not found.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Editor</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>">
</head>

<!-- Navigation bar -->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

<body>
    <main class="admin-dashboard">       

        <!--Form to edit user destials-->
        <form method="POST" action="admin_update_user.php">
            <legend>Edit User</legend>

            <!--Hidden field to store user's email for identification-->
            <input type="hidden" name="email" value="<?= htmlspecialchars($user['email']) ?>">

            <!--Pre-filled fields with option for new password-->
            <input type="text" name="fname" value="<?= htmlspecialchars($user['fname']) ?>" required>
            <input type="text" name="lname" value="<?= htmlspecialchars($user['lname']) ?>" required>
            <input type="password" name="password" placeholder="New Password (leave blank to keep current)">
            <button type="submit">Update</button>
            <a href="eAdmin.php"><button>Cancel</button></a>    <!--Return back to dashboard-->
        </form>
    </main>
</body>

</html>