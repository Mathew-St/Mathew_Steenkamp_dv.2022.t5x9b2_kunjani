<?php
//Script to be run when populating admins of website, ONLY BACKEND for SECURITY
require 'dbConnection.php';

//Input email and password (can also be fetched from a form if needed)
$admin_email = "admin@example.com";
$admin_password = "AdminPassword123"; // Use a strong password

//Hash the password
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

//Prepare and execute the insert statement
$stmt = $conn->prepare("INSERT INTO admin (email, password) VALUES (?, ?)");
$stmt->bind_param("ss", $admin_email, $hashed_password);

if ($stmt->execute()) {
    echo "Admin user successfully added.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
