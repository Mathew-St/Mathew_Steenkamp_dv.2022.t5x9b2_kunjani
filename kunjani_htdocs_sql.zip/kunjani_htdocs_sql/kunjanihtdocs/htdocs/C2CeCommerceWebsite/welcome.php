<?php
session_start();
require 'dbConnection.php'; //DB connection file

$email = $_SESSION['email'] ?? null;   //Get user email from session, if not set, it will be null

//Check if user is logged in:
if (!$email) {
    header('Location: eLogin.php');
    exit();
}

//Check if buyer
//Prepared statements: https://www.php.net/manual/en/mysqli.prepare.php
$isBuyer = false;
if ($email) {
    $stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");    //? is paramter marker to prevent SQL injection (https://www.php.net/manual/en/mysqli.prepare.php)
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $isBuyer = $result && $result->num_rows > 0;   //Means user is a buyer if there are rows returned
    $stmt->close();
}

if (!$isBuyer) {
    include 'buyerRegistrationPopup.php';
}

//           SEARCH AND CATEGORIES
//Get all products from all sellers
$products = [];
//?? are null coalescing operators, if exists and is not null, else default to avoid unindexed errors (https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce)
$searchQuery = $_GET['search'] ?? ''; //Get search query from URL, if not set, it will be empty
$category = $_GET['category'] ?? ''; //Get category, if not set, it will be empty

//Dynamic query based on based on search input and category filters
//Shows unsold products only
$query = "SELECT products.*, sellers.profile_photo FROM products 
          JOIN sellers ON products.seller_id = sellers.seller_id 
          WHERE 1=1 AND products.is_sold = 0"; //1=1 is a placeholder to simplify adding conditions (https://pushmetrics.io/blog/why-use-where-1-1-in-sql-queries-exploring-the-surprising-benefits-of-a-seemingly-redundant-clause/#:~:text=In%20SQL%2C%20the%20WHERE%20clause,not%20filter%20out%20any%20records.)

$parameters = []; //Array to hold parameters for prepared statement

//Add LIKE condition if search query provided
if (!empty($searchQuery)) {
    $query .= " AND (products.name LIKE ? OR products.description LIKE ?)"; //Search in name and description
    $searchTerm = "%" . $searchQuery . "%"; //Wildcards allow for partial matches (query phone and smartphone still shows)
    $parameters[] = $searchTerm;    //Adds search term for name
    $parameters[] = $searchTerm;    //Adds search term for description
}

//Add category condition if provided
if (!empty($category) && $category !== 'All Categories') {      //Check if category is provided and not 'All Categories' (else add no cat filter)
    $query .= " AND products.category = ?";                 //Adds category filter if provided
    $parameters[] = $category;                              //Adds category to parameters
}

//Final Search query
$stmt = $conn->prepare($query);
if ($stmt) {
    //ONly bind parameters if there are any
    if (!empty($parameters)) {  //Check if there are parameters to bind (if empty search and no category = no parameters)
        //Dynamically bind parameters based on how many there are
        $types = str_repeat('s', count($parameters)); //Create a string of 's' for each parameter (all strings)
        //Spread Operators: https://www.php.net/manual/en/functions.arguments.php#functions.variable-length-argument-lists
        $stmt->bind_param($types, ...$parameters); //Spread operator = bind all parameters at once (as array)
    }
    $stmt->execute();
    $result = $stmt->get_result(); //Get the result set from the executed query
    if ($result) {
        $products = $result->fetch_all(MYSQLI_ASSOC); //Get all products as an associative array
    }
    $stmt->close();
}
?>



<!--HTML-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

</head>

<body>
    <!-- Navigation bar -->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <ul>
                <li><a href="welcome.php" class="active">Buy</a></li>
                <li><a href="sell.php">Sell</a></li>
                <li><a href="order.php">Orders</a></li>
            </ul>
            <span class="separator">|</span>
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <!-- Search Pane -->
        <div class="wrapper">
            <div id="search-container">
                <!--Form to retain search -->
                <form id="search-form" action="welcome.php" method="GET">
                    <input type="search" name="search" id="search-input" placeholder="Search for products..." value="<?= htmlspecialchars($searchQuery) ?>">
                    <button type="submit" id="search-button">Search</button>
                </form>
            </div>

            <div id="categories">
                <!--Form to retain category selection -->
                <form id="category-form" action="welcome.php" method="GET">
                    <button type="submit" name="category" value="All Categories" class="category-button">All Categories</button>
                    <button type="submit" name="category" value="Health & Lifestyle" class="category-button">Health & Lifestyle</button>
                    <button type="submit" name="category" value="Electronics" class="category-button">Electronics</button>
                    <button type="submit" name="category" value="Home & Braai" class="category-button">Home & Braai</button>
                    <button type="submit" name="category" value="Fashion" class="category-button">Fashion</button>
                    <button type="submit" name="category" value="Garden & Outdoor" class="category-button">Garden & Outdoor</button>
                    <button type="submit" name="category" value="Lekker Food" class="category-button">Lekker Food</button>
                    <button type="submit" name="category" value="Sports & Fitness" class="category-button">Sports & Fitness</button>
                </form>
            </div>
        </div>

        <!-- Products Section -->
        <div class="catalog">
            <!--Products not found -->
            <?php if (empty($products)): ?>
                <p style="text-align:center; padding: 20px; font-size: 18px; color: black;">No products found...</p>
            <!--Products found -->
            <?php else: ?>
                <!--Loop through each product in array and display it -->
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <!--Seller Profile Photo (top-left) -->
                        <?php if ($product['profile_photo']): ?> <!--Check if profile photo exists -->
                            <div class="seller-pfp">
                                <img src="<?= htmlspecialchars($product['profile_photo']) ?>" class="seller-avatar">
                            </div>
                        <?php endif; ?>


                        <!--Product Image -->
                        <?php if ($product['image']): ?> <!--Check if product image exists -->
                            <img src="<?= htmlspecialchars($product['image']) ?>">
                        <?php endif; ?>

                        <!--Product Details -->
                        <div class="product-details">
                            <h3><?= htmlspecialchars($product['name']) ?></h3>
                            <h4><?= htmlspecialchars($product['category']) ?></h4>
                            <p><?= htmlspecialchars($product['description']) ?></p>
                            <p class="price"><strong>R<?= number_format($product['price'], 2) ?></strong></p> <!--Formatted price with 2 decimal places -->

                            <!--Add to Cart Button -->
                            <button class="add-to-cart" onclick="addToCart(<?= $product['product_id'] ?>)">
                                <i class="fas fa-shopping-cart"></i></button> <!--On click, calls addToCart() with product ID -->
                        </div>
                    </div>
                <?php endforeach; ?> <!--End of product loop -->
            <?php endif; ?>
        </div>
    </main>

    <!-- Footer Section -->
    <footer>
        <div class="footer-content">
            <div class="column">
                <img class="logo" src="images/Kunji.png" alt="Kunjani Logo">
            </div>

            <div class="column">
                <h4>Contact</h4>
                <p><strong>Address:</strong> 64 Edward Road, Tygervalley, Cape Town</p>
                <p><strong>Phone:</strong> (+27) 021 445 9782</p>
                <p><strong>Hours:</strong> 09:00 - 17:00, Mon - Sat</p>
            </div>

            <div class="column">
                <h4>About</h4>
                <a href="#">About Kunjani</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
                <a href="#">Help</a>
            </div>

            <div class="column">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
                <div class="Payment-methods">
                    <p>Secured Payment Gateways</p>
                    <img src="images/pay/pay.png" alt="Payment methods">
                </div>

            </div>
        </div>

        <div class="copyright">
            <p>&copy; 2025 Kunjani - eCommerce by Mathew. All Rights Reserved.</p>
        </div>

    </footer>

    <!--Buyer Registration Popup script-->
    <script>
        // Message display function
        //Source: https://www.w3schools.com/howto/howto_js_popup.asp
        function showMessage(text, isError = false) {
            const popup = document.getElementById('message-popup'); //Get the popup element
            popup.textContent = text; //Set the text of the popup
            popup.style.display = 'block'; //Show the popup
            popup.style.backgroundColor = isError ? '#f44336' : '#4CAF50'; //Set background color based on error or success

            setTimeout(() => { //Hide the popup after 3 seconds
                popup.style.display = 'none';
            }, 3000);
        }

        //Buyer popup functions
        function showBuyerPopup() {
            document.getElementById('buyerPopupBackdrop').style.display = 'block';
            document.getElementById('buyerPopupContainer').style.display = 'block';
            document.body.classList.add('body-no-scroll');
        }
        //Function to hide the buyer registration popup
        function hideBuyerPopup() {
            document.getElementById('buyerPopupBackdrop').style.display = 'none';
            document.getElementById('buyerPopupContainer').style.display = 'none';
            document.body.classList.remove('body-no-scroll');
        }

        //Fetch API used to send the product ID to the server and add the item to the cart
        //Fetch API used to make network requests
        //API key fetching Source: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
        function addToCart(product_id) {
            //User is a buyer, proceed with adding in cart
            <?php if ($isBuyer): ?> //Check performed at top in php                
                //Which product to add to cart
                sendToServer('addToCart.php', product_id).then(result => {
                    //Server responds with JSON, e.g. {"success": true}
                    if (result.success) {
                        showMessage("Added to cart!"); //1. If successful, show success message
                    } else {
                        //Sserver provide an error message
                        showMessage(result.error || "Product already added to cart!");
                    }
                }).catch(error => {
                    //3. If there's an error in the network fetch request, show error message
                    showMessage("Something went wrong when fetching");
                    console.log(error); //For error debugging
                });

                //Helper function that sends the product ID to the server
                //Source:  https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
                function sendToServer(url, product_id) {
                    return fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded' //'application/x-www-form-urlencoded' is used for form data
                        },
                        body: 'product_id=' + product_id //Send product ID in the body of the POST request
                    }).then(response => response.json()); //Parse the response as JSON because the server returns a JSON response
                }
            <?php else: ?>
                //User is not a buyer - calls registration popup
                showBuyerPopup();
            <?php endif; ?>
        }
    </script>

    <!--Message Popup Functionality -->
    <div id="message-popup" style="display:none; position:fixed; bottom:20px; right:20px; background:#4CAF50; color:white; padding:15px; border-radius:4px;"></div>

    <?php if (!$isBuyer): ?>
        <?php include 'buyerRegistrationPopup.php'; ?>
    <?php endif; ?>
</body>

</html>