<?php
require 'dbConnection.php'; //DB connection file

$email = $_SESSION['email'] ?? null; //Get user email from session, if not set, it will be null (https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce)

//Check if user is logged in and form submitted
if ($_SERVER["REQUEST_METHOD"] === "POST" && $email) {
    $address = $_POST['address'];           //Get address from form

    //Upload profile photo file
    $target_dir = "uploads/buyers/";        // Directory where the profile photo will be uploaded
    $target_file = $target_dir . uniqid() . "_" . basename($_FILES["profile_photo"]["name"]);   //Full path to the uploaded file with a unique ID to avoid overwriting files ( https://www.php.net/manual/en/function.basename.php)

    //Move the uploaded file to the target directory (https://www.php.net/manual/en/function.move-uploaded-file.php)
    if (move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $target_file)) {
        //Insert new buyer
        $stmt = $conn->prepare("INSERT INTO buyers (user_id, address, profile_photo) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $address, $target_file);   //Bind parameters: user_id, address, profile_photo
        $stmt->execute();

        $stmt->close();

        //Redirect back to welcome page after registration
        header("Location: welcome.php");
        exit();
    } else {
        die("File upload failed.");
    }
}

//Check if user is already a buyer
$isBuyer = false;
if ($email) {
    $stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $isBuyer = $result && $result->num_rows > 0;   //Means user is a buyer if there are rows returned
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer RegPopup</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>"> <!-- General styles -->
</head>

<body>
    <!--If !buyer = Popup for Buyer Registration -->
    <?php if (!$isBuyer): ?>
        <div class="popup-backdrop" id="buyerPopupBackdrop"></div>
        <div class="popup-container" id="buyerPopupContainer">
            <form class="buyer-form" method="POST" enctype="multipart/form-data"> <!--Multipart form to handle file uploads (https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#enctype)-->
                <fieldset>
                    <legend>Become a Buyer</legend>
                    <label for="profile_photo">Profile Photo</label>
                    <input type="file" name="profile_photo" accept="image/*" required>  <!--Accept only only image files in the file picker-->

                    <label for="address">Address</label>
                    <input type="text" name="address" required>

                    <button type="submit">Register as Buyer</button>
                    <button type="button" class="back-button" onclick="hideBuyerPopup()">Cancel</button>
                </fieldset>
            </form>
        </div>
    <?php endif; ?>

</body>

</html>