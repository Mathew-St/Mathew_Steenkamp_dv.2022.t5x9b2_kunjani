<?php
require 'dbConnection.php';

//Null Coalescing Operator (https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce)
$email = $_SESSION['email'] ?? null;        //Retrieve user email from session, if not set, it will be null

//Check if user is logged in and form submitted
if ($_SERVER["REQUEST_METHOD"] === "POST" && $email) {        
    $address = $_POST['address'];                               //Get address from form 

    //Upload profile photo file
    $target_dir = "uploads/";                 //Directory where the profile photo will be uploaded   
    $target_file = $target_dir . uniqid() . "_" . basename($_FILES["profile_photo"]["name"]);   //Full path to the uploaded file with a unique ID to avoid overwriting files (https://www.php.net/manual/en/function.basename.php)


    if (move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $target_file)) {        //Move the uploaded file to the target directory (https://www.php.net/manual/en/function.move-uploaded-file.php)
        $stmt = $conn->prepare("INSERT INTO sellers (user_id, address, profile_photo) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $address, $target_file);  //Bind parameters: user_id, address, profile_photo (https://www.php.net/manual/en/mysqli-stmt.bind-param.php)
        $stmt->execute();  //Execute the prepared statement 

        $stmt->close();  //Close the prepared statement

        //Redirect to the sell page after successful registration
        header("Location: sell.php");
        exit();
    } else {
        die("File upload failed.");
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller RegPopup</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>"> <!-- General styles -->
   

</head>

<body>
    <!--Popup Form for Seller Registration-->
    <div class="popup-backdrop"></div>
    <div class="popup-container">
        <form class="seller-form" method="POST" enctype="multipart/form-data">  <!--Multipart form to handle file uploads (https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#enctype)-->
            <fieldset>
                <legend>Become a Seller</legend>

                <label for="profile_photo">Profile Photo</label>
                <input type="file" name="profile_photo" accept="image/*" required> <!--Accept only only image files in the file picker-->

                <label for="address">Address</label>
                <input type="text" name="address" required>

                <button type="submit">Register as Seller</button>
                <button type="button" class="back-button" onclick="hideSellerPopup()">Back</button>
            </fieldset>
        </form>
    </div>  


</body>

</html>