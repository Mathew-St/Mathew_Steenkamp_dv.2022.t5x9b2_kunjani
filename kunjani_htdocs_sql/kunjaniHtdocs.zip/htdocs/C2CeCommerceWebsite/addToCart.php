<?php
session_start();
require 'dbConnection.php';

//Set the content typeof browser to JSON for the response (https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Type)
header('Content-Type: application/json');   

//Null coalescing operator if not set
$email = $_SESSION['email'] ?? null;
$product_id = $_POST['product_id'] ?? null;     //Get product ID from POST request, if not set, it will be null

if (!$email || !$product_id) {  //Check if user is logged in and product ID is provided
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);    //Return JSON response with error message if validation fails
    exit();
}

//Get the buyer_id using the user's email (FK)
$stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();  //Source: https://www.php.net/manual/en/mysqli-stmt.get-result.php
$buyer = $result->fetch_assoc();
$stmt->close();

//No buyer, returns error message
if (!$buyer) {
    echo json_encode(['success' => false, 'message' => 'Not a buyer']);
    exit();
}

//Got from querying FK in buyers
$buyer_id = $buyer['buyer_id'];

//Check if the product is already in the cart
$stmt = $conn->prepare("SELECT * FROM cart WHERE buyer_id = ? AND product_id = ?");
$stmt->bind_param("ii", $buyer_id, $product_id);
$stmt->execute();
$prodCheck = $stmt->get_result();
$stmt->close();

//If not in cart, insert
if ($prodCheck->num_rows === 0) {
    //Insert into cart
    $stmt = $conn->prepare("INSERT INTO cart (buyer_id, product_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $buyer_id, $product_id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
} else {
    //Already in cart
    echo json_encode(['success' => false, 'message' => 'Already in cart']);
}

?>