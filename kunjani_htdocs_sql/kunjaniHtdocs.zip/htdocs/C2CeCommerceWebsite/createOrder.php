<?php
session_start();
require 'dbConnection.php';

$email = $_SESSION['email'] ?? null;    //Source https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce

//Check if logged in
if (!$email) {
    header('Location: eLogin.php');
    exit();
}

//Get buyer info using user_id
$buyer_id = null; //Initialise to null
$stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $buyer_id = $row['buyer_id'];   //Get buyer_id using key
} else {
    //Buyer does not exist
    header('Location: cart.php');
    exit();
}
$stmt->close();

//Get cart items by joining cart to products table
$stmt = $conn->prepare("SELECT p.product_id, p.seller_id, p.price FROM cart c 
    JOIN products p ON c.product_id = p.product_id 
    WHERE c.buyer_id = ?");
$stmt->bind_param("i", $buyer_id);
$stmt->execute();
$cart_items = $stmt->get_result();

//Create order ( https://www.php.net/manual/en/mysqli.begin-transaction.php)
$conn->begin_transaction();

try {
    //Insert order record with placeholder
    $order_date = date('Y-m-d H:i:s'); //Current date and time
    $stmt = $conn->prepare("INSERT INTO orders (buyer_id, order_date, total_amount) VALUES (?, ?, 0)");
    $stmt->bind_param("is", $buyer_id, $order_date);
    $stmt->execute();
    $order_id = $stmt->insert_id;   //Id of new order
    $stmt->close();

    //Intitalise total amount
    $total_amount = 0;

    //Insert each order item 
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, seller_id, price) VALUES (?, ?, ?, ?)");
    while ($item = $cart_items->fetch_assoc()) {
        $stmt->bind_param("iiid", $order_id, $item['product_id'], $item['seller_id'], $item['price']);
        $stmt->execute();

        //Tally total amount
        $total_amount += $item['price'];
    }
    $stmt->close();

    //Update order total placeholder with actual total
    $stmt = $conn->prepare("UPDATE orders SET total_amount = ? WHERE order_id = ?");
    $stmt->bind_param("di", $total_amount, $order_id);
    $stmt->execute();
    $stmt->close();

    //Clear cart after order placed
    $stmt = $conn->prepare("DELETE FROM cart WHERE buyer_id = ?");
    $stmt->bind_param("i", $buyer_id);
    $stmt->execute();
    $stmt->close();

    //Update products status from products table as sold (initially set as 0 for unsold)
    $stmt = $conn->prepare("UPDATE products p JOIN order_items oi ON p.product_id = oi.product_id
    SET p.is_sold = 1 WHERE oi.order_id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $stmt->close();

    //Commit transaction (https://www.geeksforgeeks.org/php-transactions-in-mysqli/)
    $conn->commit();

    //Show status and order #
    $_SESSION['order_success'] = "Your order #$order_id has been placed successfully!";
    header('Location: order.php');
    exit();

} catch (Exception $e) {
    //Rollback on failure
    $conn->rollback();  
    $_SESSION['order_error'] = "There was an error processing your order. Please try again.";   //Ensures not partial data is saved (https://www.w3schools.com/php/func_mysqli_rollback.asp)
    header('Location: checkout.php');
    exit();
}
