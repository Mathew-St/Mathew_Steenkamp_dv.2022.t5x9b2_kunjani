<?php
session_start();
require 'dbConnection.php';

//Verify ownership of product, such that belongs to seller
//Joins the products and sellers tables to link a product_id to a user's email
$stmt = $conn->prepare("SELECT p.product_id FROM products p
                       JOIN sellers s ON p.seller_id = s.seller_id
                       WHERE p.product_id = ? AND s.user_id = ?");
$stmt->bind_param("is", $_POST['product_id'], $_SESSION['email']);
$stmt->execute();
$result = $stmt->get_result();

//Product does not exist or not owned by seller
if ($result->num_rows === 0) {
    $_SESSION['error'] = "Product not found or access denied";
    header("Location: sell.php");
    exit;
}

//Handle file upload
$imagePath = null;  //Initialise image path variable as null

//Check if file is uploaded, by seeing if name is not empty
//Source: https://www.php.net/manual/en/features.file-upload.post-method.php
if (!empty($_FILES["image"]["name"])) {
    $target_dir = "uploads/products/";
    $target_file = $target_dir . uniqid() . "_" . basename($_FILES["image"]["name"]); //Unique ID to avoid overwriting files (https://www.php.net/manual/en/function.move-uploaded-file.php)    
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $imagePath = $target_file;  //If successful uplaod, path is updated
    }
}

//Update product with dynamic query
//Ternary operator to see if imagePAth is null or not, If not null = image added to query
//Source: https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.ternary
$update = $conn->prepare("UPDATE products SET name = ?, category = ?, description = ?,
    price = ?" .  ($imagePath ? ", image = ?" : "") . " WHERE product_id = ?");

//Array for binding parameters
$params = [
    $_POST['name'],
    $_POST['category'],
    $_POST['description'],
    $_POST['price']
];

//New images' path added to array (if new)
if ($imagePath) {
    $params[] = $imagePath;
}
$params[] = $_POST['product_id'];       //ProdID is last parameter

//Type parameter dynamically bound (depends on strings / int for prodID)
$types = str_repeat('s', count($params) - 1) . 'i';
$update->bind_param($types, ...$params);    //Spread operator handles variable amount of parameters (Source: https://www.php.net/manual/en/functions.arguments.php#functions.variable-length-argument-lists)

//Updates and alerts on status
if ($update->execute()) {
    $_SESSION['success'] = "Product updated successfully";
} else {
    $_SESSION['error'] = "Error updating product";
}

header("Location: sell.php");
exit;