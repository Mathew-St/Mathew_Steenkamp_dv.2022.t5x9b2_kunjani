<?php
require 'dbConnection.php';

//Get input from form 
$email = $_POST["email"];
$fname = $_POST["fname"];
$lname = $_POST["lname"];
$password = $_POST["password"];

//Validate password not empty, hash it and update
if (!empty($password)) {
    $password = password_hash($password, PASSWORD_DEFAULT); //Source: https://www.php.net/manual/en/function.password-hash.php
    $stmt = $conn->prepare("UPDATE users SET fname=?, lname=?, password=? WHERE email=?");
    $stmt->bind_param("ssss", $fname, $lname, $password, $email);
} else {
    //Update first, last names for user's email if password empty
    $stmt = $conn->prepare("UPDATE users SET fname=?, lname=? WHERE email=?");
    $stmt->bind_param("sss", $fname, $lname, $email);
}

//Execute update
$stmt->execute();

//Redirect to dashboard on success
header("Location: eAdmin.php");
exit;
?>
