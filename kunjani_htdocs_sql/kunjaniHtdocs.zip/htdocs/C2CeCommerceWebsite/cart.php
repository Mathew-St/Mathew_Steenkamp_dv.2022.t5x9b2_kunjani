<?php
session_start();
require 'dbConnection.php';

$email = $_SESSION['email'] ?? null;  //Get user email from session, if not set, it will be null (https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce)

//Check if user is logged in 
if (!$email) {
    header('Location: eLogin.php');
    exit();
}

//Get buyer_id PK with user_id
$stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$buyer = $result->fetch_assoc();
$buyer_id = $buyer['buyer_id'] ?? null;  //Get buyer_id, if not found, it will be null
$stmt->close();

//Not registered as buyer = no cart
if (!$buyer) {
    echo "<p>Your cart is empty. Add products to cart.</p>";
    exit();
}

//Get cart items with product and seller info (JOIN products, sellers and users)
//Concat joins strings together (https://www.w3schools.com/sql/func_mysql_concat.asp)
$stmt = $conn->prepare("SELECT cart.product_id, products.name AS product_name, products.price, 
    CONCAT(users.fname, ' ', users.lname) AS seller_name FROM cart                     
    JOIN products ON cart.product_id = products.product_id
    JOIN sellers ON products.seller_id = sellers.seller_id
    JOIN users ON sellers.user_id = users.email
    WHERE cart.buyer_id = ?");

$stmt->bind_param("i", $buyer_id);
$stmt->execute();
$result = $stmt->get_result();

//Initialise total price
$total = 0;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
</head>

<body>
    <!-- Navigation bar -->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <ul>
                <li><a href="welcome.php">Buy</a></li>
                <li><a href="sell.php">Sell</a></li>
                <li><a href="order.php">Orders</a></li>
            </ul>
            <span class="separator">|</span>
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                    <li><a href="cart.php" class="active"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <form method="post" action="removeFromCart.php" class="cart-form">
            <h2>Your Cart</h2>
            <!--Display removal message-->
            <div id="message-container">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert success"><?= $_SESSION['success'] ?></div>    <!--Flash message-->
                    <?php unset($_SESSION['success']); ?>           <!--Removes variable after display-->
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert error"><?= $_SESSION['error'] ?></div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
            </div>

            <?php if ($result->num_rows === 0): ?>
                <p>Your cart is empty. Add products to cart.</p>
            <?php else: ?>
                <ul>
                    <?php $total = 0; ?>
                    <!--While loop to iterate through rows w/ key and value (https://www.php.net/manual/en/mysqli-result.fetch-assoc.php)-->
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <li>
                            <!--Create item with formatted price and seller name-->
                            <div class="item-info">
                                <?= htmlspecialchars($row['product_name']) ?> - R<?= number_format($row['price'], 2) ?>
                                <br><small>Seller: <?= htmlspecialchars($row['seller_name']) ?></small>
                            </div>

                            <!--Remove button-->
                            <button type="submit" name="product_id" value="<?= $row['product_id'] ?>"
                                class="remove-btn" onclick="return confirm('Remove this item from your cart?')">
                                <i class="fas fa-times"></i>
                            </button>
                        </li>

                        <!--Calculate total price-->
                        <?php $total += $row['price']; ?>
                    <?php endwhile; ?>
                </ul>

                <!--Display total-->
                <h3>Total: R<?= number_format($total, 2) ?></h3>

                <!--Proceed to checkout button-->
                <div class="checkout-btn-container">
                    <!--Allow for checkout.php and removeFromCart.php-->
                    <button type="submit" formaction="checkout.php" class="checkout-btn">Proceed to Checkout</button>   <!--`formaction` attribute overrides the main form action (https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#formaction)-->
                </div>
            <?php endif; ?>
        </form>
    </main>

    <!-- Footer Section -->
    <footer>
        <div class="footer-content">
            <div class="column">
                <img class="logo" src="images/Kunji.png" alt="Kunjani Logo">
            </div>

            <div class="column">
                <h4>Contact</h4>
                <p><strong>Address:</strong> 64 Edward Road, Tygervalley, Cape Town</p>
                <p><strong>Phone:</strong> (+27) 021 445 9782</p>
                <p><strong>Hours:</strong> 09:00 - 17:00, Mon - Sat</p>
            </div>

            <div class="column">
                <h4>About</h4>
                <a href="#">About Kunjani</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
                <a href="#">Help</a>
            </div>

            <div class="column">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
                <div class="Payment-methods">
                    <p>Secured Payment Gateways</p>
                    <img src="images/pay/pay.png" alt="Payment methods">
                </div>

            </div>
        </div>

        <div class="copyright">
            <p>&copy; 2025 Kunjani - eCommerce by Mathew. All Rights Reserved.</p>
        </div>

    </footer>

    <script>
        //Auto-hide messages after 3 seconds
        document.addEventListener('DOMContentLoaded', function() {  //DOM maniupulation ensures script doesn't run until entire HTML loaded (https://developer.mozilla.org/en-US/docs/Web/API/Document/DOMContentLoaded_event)
            const messages = document.querySelectorAll('.alert');

            //set timeout for delayed flash
            messages.forEach(message => {
                //Fade out after 3 seconds
                setTimeout(() => {
                    message.style.transition = 'opacity 0.5s ease';
                    message.style.opacity = '0';

                    //Remove from DOM after fade transition completes
                    setTimeout(() => {
                        message.remove();
                    }, 500);
                }, 3000); //3000ms = 3 seconds
            });
        });
    </script>
</body>

</html>