<?php
session_start();
require 'dbConnection.php';

//Null Coalescing Operator, if not set, it will be null (check logged in user and prodID from POST request)
$email = $_SESSION['email'] ?? null;
$product_id = $_POST['product_id'] ?? null; //From form

//Validate exists
if (!$email || !$product_id) {
    $_SESSION['error'] = "You need to be logged in to modify your cart";
    header("Location: cart.php");
    exit();
}

// Get buyer_id
$stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();      //Source: https://www.php.net/manual/en/mysqli-stmt.get-result.php
$buyer = $result->fetch_assoc();
$stmt->close();

//If user not registered as buyer, redirect
if (!$buyer) {
    $_SESSION['error'] = "You need to be a registered buyer to modify your cart";
    header("Location: cart.php");
    exit();
}

//If buyer, delete item from cart use buyer id and prod id
$stmt = $conn->prepare("DELETE FROM cart WHERE buyer_id = ? AND product_id = ?");
$stmt->bind_param("ii", $buyer['buyer_id'], $product_id);

//Define success messages of execution
if ($stmt->execute()) {
    $_SESSION['success'] = "Item successfully removed from your cart";
} else {
    $_SESSION['error'] = "Failed to remove item from cart";
}

$stmt->close();

header("Location: cart.php"); //Always redirect back to cart.php
exit();
?>