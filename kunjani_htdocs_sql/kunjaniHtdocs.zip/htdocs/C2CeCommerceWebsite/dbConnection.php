<?php
//For establishing general connections to db

//Database connection variables
$host = "sql312.infinityfree.com";
$db_user = "if0_39183935";
$db_password = "1N7SqGZa1pdyb3";
$db_name = "if0_39183935_kunjani";

//Create connection: mySQLI OO approach (W3Schools - Prepared statements)
$conn = new mysqli($host, $db_user, $db_password, $db_name);

//Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Set charset to avoid encoding issues
$conn->set_charset("utf8mb4");
