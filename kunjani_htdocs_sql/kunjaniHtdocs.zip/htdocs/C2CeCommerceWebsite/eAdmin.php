<?php
session_start();

require 'dbConnection.php'; //DB connection file (https://www.php.net/manual/en/function.require.php)
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management Dashboard</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

</head>

<body>
    <!-- Navigation bar -->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="admin-dashboard">
        <h2 class="admin-greeting">Kunjani, Admin. Ready to manage some users?</h2>

        <!--Display Users Table -->
        <section class="user-management">           

            <div class="user-management">
                <!--Adding User Form, links to admin_create_user.php with POST request-->
            <form method="POST" action="admin_create_user.php" class="user-form">
                <input type="text" name="fname" placeholder="First Name" required>
                <input type="text" name="lname" placeholder="Last Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Add User</button>
            </form>

            <!--Users Table -->
            <table>
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <!--Fetch all users from DB (https://www.php.net/manual/en/function.mysqli-query.php)-->
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM users");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>{$row['email']}</td>";
                        echo "<td>{$row['fname']} {$row['lname']}</td>";

                        //Admins control buttons for editing and deleting users
                        echo "<td>
                            <a href='admin_edit_user.php?email={$row['email']}' class='btn-edit'>Edit</a>
                            <a href='admin_delete_user.php?email={$row['email']}' class='btn-delete' onclick='return confirm(\"Delete this user and related data?\")'>Delete</a>
                          </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
            </div>
            
        </section>
    </main>   

</body>

</html>