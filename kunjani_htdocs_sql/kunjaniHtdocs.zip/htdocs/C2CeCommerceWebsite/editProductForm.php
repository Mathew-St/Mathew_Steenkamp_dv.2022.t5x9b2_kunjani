<?php
$product_id = $_GET['edit_product'];    //Scipt inlcuded in sell.php with URL with parameter
//Fetch product details
$stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ? AND seller_id = ?");    //Access to only that seller's products
$stmt->bind_param("ii", $product_id, $seller['seller_id']);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

//If no product is found it does not exist or isn't owned by seller
if (!$product) {
    die("Product not found or does not belong to this seller!");
}
?>

<!--`enctype="multipart/form-data"` attribute for forms that include file uploads (Source: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#enctype)-->
<form class="product-form" method="POST" action="updateProduct.php" enctype="multipart/form-data">  
    <fieldset>
        <legend>Edit Product</legend>

        <input type="hidden" name="product_id" value="<?= $product_id ?>">

        <label for="name">Product Name</label>
        <input type="text" name="name" maxlength="100" value="<?= htmlspecialchars($product['name']) ?>" required> <!--'htmlspecialchars()` function used XSS attacks (Source: https://www.php.net/manual/en/function.htmlspecialchars.php)-->

        <label for="category">Select Category</label>
        <select name="category" id="category" required>
            <?php
            $categories = [
                "Health & Lifestyle",
                "Electronics",
                "Home & Braai",
                "Fashion",
                "Garden & Outdoor",
                "Lekker Food",
                "Sports & Fitness"
            ];

            //Ternary operator to add selected category
            //Source: https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.ternary
            foreach ($categories as $cat): ?>
                <option value="<?= $cat ?>" <?= $product['category'] === $cat ? 'selected' : '' ?>>
                    <?= $cat ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="description">Description</label>
        <input type="text" name="description" maxlength="255" value="<?= htmlspecialchars($product['description']) ?>" required>

        <label for="price">Price (R)</label>
        <input type="number" name="price" step="0.01" min="0" value="<?= $product['price'] ?>" required>

        <label for="image">Product Image</label>
        <input type="file" name="image" accept="image/*">
        <?php if ($product['image']): ?>
            <div class="current-image">
                <small>Current Image:</small>
                <img src="<?= htmlspecialchars($product['image']) ?>" alt="Current Product Image" style="max-width: 100px;">
            </div>
        <?php endif; ?>

        <div class="form-actions">
            <button type="submit" class="save-btn">Save Changes</button>
            <button type="button" class="delete-btn" onclick="confirmDelete(<?= $product_id ?>)">Delete Product</button>
            <button type="button" class="back-button" onclick="hideEditPopup()">Cancel</button>
        </div>
    </fieldset>
</form>