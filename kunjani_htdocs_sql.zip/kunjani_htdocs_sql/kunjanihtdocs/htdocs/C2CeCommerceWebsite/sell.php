<?php
session_start();

require 'dbConnection.php'; //DB connection file

$email = $_SESSION['email'] ?? null;   //Retrieve user email from session, if not set, it will be null (//Null coalescing operator source: https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce)

//Check if user is logged in:
if (!$email) {
    header('Location: eLogin.php');
    exit();
}

//Check if the user is already a seller:
$seller = null;                      //Initialize seller variable to null
$showSellerPopup = false;            //Flag to show seller registration popup
//Prepared statements source: https://www.php.net/manual/en/mysqli.prepare.php
$stmt = $conn->prepare("SELECT * FROM sellers WHERE user_id = ?");      //Get seller info (? is placeholder and will be bound later)
if ($stmt) {
    $stmt->bind_param("s", $email);  //Bind the user ID as a string parameter
    $stmt->execute();                //Execute the query
    $result = $stmt->get_result();   //Get the result set from the executed query

    if ($result && $result->num_rows > 0) {           //Check if any rows were returned (first check if result is not false)
        //If there are rows, it means the user is a seller
        $seller = $result->fetch_assoc();                //Get seller's data as an associative array (set of key-value pairs) (https://www.php.net/manual/en/mysqli-result.fetch-assoc.php)
    } else {
        //If no rows were returned, the user is not a seller
        $showSellerPopup = true;                         //Set flag to show the seller registration popup if not seller
    }
    $stmt->close();
}

$products = []; // Initialize $products as an empty array
//Fetch seller products only if exist
if ($seller) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE seller_id = ? AND is_sold = 0");   //Get unsold products for the seller
    if ($stmt) {
        $stmt->bind_param("i", $seller['seller_id']); //Use seller_id from the database query
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result) {
            $products = $result->fetch_all(MYSQLI_ASSOC); //Get all products as an associative array (https://www.php.net/manual/en/mysqli-result.fetch-all.php)
        }
        $stmt->close();
    }
}

//Prevents header clash error if output is sent before header:
//Include seller registration popup logic if user is not a seller
if ($showSellerPopup) {
    include 'sellerRegistrationPopup.php';
}

//Include product addition popup logic if user is a seller
if ($seller) {
    include 'addProductPopup.php';
}
?>



<!--HTML-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Dashboard</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>"> <!-- General styles -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

</head>

<body>
    <!-- Navigation bar -->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <ul>
                <li><a href="welcome.php">Buy</a></li>
                <li><a href="sell.php" class="active">Sell</a></li>
                <li><a href="order.php">Orders</a></li>
            </ul>
            <span class="separator">|</span>
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>



    <main>
        <!-- Personalized greeting title -->
        <h2 class="seller-greeting">
            <?php if (isset($_SESSION['fname'])): ?> <!-- If first name is set in session, greet the user by name -->
                Kunjani <?= htmlspecialchars($_SESSION['fname']) ?>, ready to stock the shelves?
            <?php else: ?> <!-- If first name is not set, use a generic greeting -->
                Kunjani, ready to stock the shelves?
            <?php endif; ?>
        </h2>

        <!--Displaying Seller's Products-->
        <div class="catalog">
            <!-- Add Product Card if user is a seller (if seller = product add; if not seller = seller registration) -->
            <div class="product-card add-card" onclick="<?= $seller ? 'showProductPopup()' : 'showSellerPopup()' ?>"> <!--Ternary operator to decide which JS function to call (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_operator)-->
                <div class="add-icon">+</div>
                <p>Add Product</p>
            </div>

            <!-- Loop through seller's products -->
            <?php foreach ($products as $product): ?> <!-- For each product, create a card (in Seller Dashboard) -->
                <div class="product-card">
                    <?php if ($product['image']): ?> <!-- Check if product has an image -->
                        <img src="<?= htmlspecialchars($product['image']) ?>" alt="Product Image">
                    <?php endif; ?>
                    <h3><?= htmlspecialchars($product['name']) ?></h3>
                    <h4><?= htmlspecialchars($product['category']) ?></h4>
                    <p><?= htmlspecialchars($product['description']) ?></p>
                    <p><strong>R<?= number_format($product['price'], 2) ?></strong></p>
                    <button class="edit-btn" onclick="showEditPopup(<?= $product['product_id'] ?>)">Edit</button>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!--Footer Section -->
    <footer>
        <div class="footer-content">
            <div class="column">
                <img class="logo" src="images/Kunji.png" alt="Kunjani Logo">
            </div>

            <div class="column">
                <h4>Contact</h4>
                <p><strong>Address:</strong> 64 Edward Road, Tygervalley, Cape Town</p>
                <p><strong>Phone:</strong> (+27) 021 445 9782</p>
                <p><strong>Hours:</strong> 09:00 - 17:00, Mon - Sat</p>
            </div>

            <div class="column">
                <h4>About</h4>
                <a href="#">About Kunjani</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
                <a href="#">Help</a>
            </div>

            <div class="column">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
                <div class="Payment-methods">
                    <p>Secured Payment Gateways</p>
                    <img src="images/pay/pay.png" alt="Payment methods">
                </div>

            </div>
        </div>

        <div class="copyright">
            <p>&copy; 2025 Kunjani - eCommerce by Mathew. All Rights Reserved.</p>
        </div>

    </footer>

    <!--Popup Form Functionality for Seller Registration -->
    <?php if ($showSellerPopup): ?>
        <?php include 'sellerRegistrationPopup.php'; ?> <!--Only if user is not a seller, include popup logic-->
        <script>
            //Function to show the seller registration popup with backdrop
            function showSellerPopup() {
                document.querySelector('.popup-backdrop').style.display = 'block';
                document.querySelector('.popup-container').style.display = 'block'; //Form
                document.body.classList.add('body-no-scroll');
            }

            //Function to hide the seller registration popup and backdrop
            function hideSellerPopup() {
                document.querySelector('.popup-backdrop').style.display = 'none';
                document.querySelector('.popup-container').style.display = 'none';
                document.body.classList.remove('body-no-scroll');
            }

            //Auto-show popup if needed, after page loads            
            //Source:  https://developer.mozilla.org/en-US/docs/Web/API/Window/load_event
            window.onload = function() {
                <?php if ($showSellerPopup): ?>
                    showSellerPopup();  //When page loads show popup if user not seller
                <?php endif; ?>
            };

            //Close when clicking on outside
            document.querySelector('.popup-backdrop').addEventListener('click', hideSellerPopup);
        </script>
    <?php endif; ?>

    <!--Popup Form Functionality for Product ADDITION -->
    <?php if ($seller): ?> <!--Only show product popup if user is a seller -->
        <?php include 'addProductPopup.php'; ?>
        <script>
            //Function to show the seller registration popup with backdrop
            function showProductPopup() {
                document.getElementById('productPopupBackdrop').style.display = 'block'; //Show backdrop on id
                document.getElementById('productPopupContainer').style.display = 'block'; //Show product popup container on id
                document.body.classList.add('body-no-scroll');
            }

            //Function to hide the seller registration popup and backdrop 
            function hideProductPopup() {
                document.getElementById('productPopupBackdrop').style.display = 'none';
                document.getElementById('productPopupContainer').style.display = 'none';
                document.body.classList.remove('body-no-scroll');
            }

            //Close when clicking on outside
            document.getElementById('productPopupBackdrop').addEventListener('click', hideProductPopup);
        </script>
    <?php endif; ?>

    <!--Popup Form Functionality for EDIT Product -->
    <?php if ($seller): ?>
        <!-- Edit Product Popup Structure -->
        <div class="product-PopupBackdrop" id="editProductPopupBackdrop"
            style="display:<?= isset($_GET['edit_product']) ? 'block' : 'none' ?>;"></div>
        <div class="product-PopupContainer" id="editProductPopupContainer"
            style="display:<?= isset($_GET['edit_product']) ? 'block' : 'none' ?>;">
            <?php if (isset($_GET['edit_product'])): ?>
                <?php include 'editProductForm.php'; ?>
            <?php endif; ?>
        </div>

        <script>
            function showEditPopup(productId) {
                //Redirect to same page with product ID
                window.location.href = 'sell.php?edit_product=' + productId;
            }

            function hideEditPopup() {
                //Redirect back without edit parameter
                window.location.href = 'sell.php';
            }

            //`confirm()` method displays dialog with OK and Cancel.
            //Confirm dialog source: https://developer.mozilla.org/en-US/docs/Web/API/Window/confirm
            function confirmDelete(productId) {
                if (confirm('Are you sure you want to delete this product?')) {
                    window.location.href = 'deleteProduct.php?product_id=' + productId;
                }
            }
        </script>
    <?php endif; ?>

</body>

</html>