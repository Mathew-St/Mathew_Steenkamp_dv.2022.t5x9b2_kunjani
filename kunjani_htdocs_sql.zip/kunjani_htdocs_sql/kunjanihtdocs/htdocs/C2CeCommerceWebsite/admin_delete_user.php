<?php
session_start();
require 'dbConnection.php';

//Debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['email'])) {
    $email = $_GET['email'];

    //Verify user exists with email
    $user_check = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $user_check->bind_param("s", $email);
    $user_check->execute();
    $user_result = $user_check->get_result();
    
    if ($user_result->num_rows > 0) {
        $conn->begin_transaction();
        try {
            //Single delete will cascade through all related tables
            $delete_stmt = $conn->prepare("DELETE FROM users WHERE email = ?");
            $delete_stmt->bind_param("s", $email);
            $delete_stmt->execute();
            
            $conn->commit();
            $_SESSION['message'] = "User deleted successfully!";
        } catch (Exception $e) {
            $conn->rollback();  //If delete fails, to ensure consistency
            $_SESSION['error'] = "Error deleting user: " . $e->getMessage();
            error_log("Deletion error: " . $e->getMessage());
        }
    } else {
        $_SESSION['error'] = "User not found!";
    }
} else {
    $_SESSION['error'] = "No email provided!";
}

header("Location: eAdmin.php");
exit;
?>