<?php
//Initialise an array to store error messages (avoids having to use multiple variables in html)
$errors = [
    'email' => '',
    'password' => '',
];

//Retrieve input values
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    //Check if empty: 
    //If empty - Update span tag in eLogin.html
    if (empty($email)) {
        $errors['email'] = "Email is required";
    }
    if (empty($password)) {
        $errors['password'] = "Password is required";
    }

    //Check format:
    //Validate email format (Built in function, no regex required as in js)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format";
    }




    //Proceed with DB connection only if there are no errors
    if (empty(array_filter($errors))) {
        //Database connection variables
        require 'dbConnection.php';

        //Create connection: mySQLI OO approach (W3Schools - Prepared statements)
        $conn = new mysqli($host, $db_user, $db_password, $db_name);

        //Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        //Check if USER loggin in is an ADMIN:
        $stmt = $conn->prepare("SELECT password FROM admin WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        //Admin found, verify password   
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();

            //Verify password
            if (password_verify($password, $hashed_password)) {
                //Start session since admin is authenticated/logged in
                session_start();
                $_SESSION['loggedin'] = true;  //Session variable to track login status
                $_SESSION['email'] = $email;    //Store email in session 

                //Password is correct, redirect to admin dashboard
                header("Location: eAdmin.php");
                exit(); //Stop script after redirection
            } else {
                //Incorrect password for admin
                $errors['password'] = "Admin password is invalid";
            }
        } else {
            //No admin found, proceed to check user login
            $stmt->close();

            //#1 Verify existence:
            //Search for password and first name for the given email (first name used for session)
            $stmt = $conn->prepare("SELECT password, fname FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            //Asserts that email exists in the database
            if ($stmt->num_rows > 0) {
                //#2 Verify password:
                $stmt->bind_result($hashed_password, $first_name);
                $stmt->fetch();

                if (password_verify($password, $hashed_password)) {
                    //Start session since user is authenticated/logged in
                    session_start();
                    $_SESSION['loggedin'] = true;  //Session variable to track login status
                    $_SESSION['email'] = $email;    //Store email in session 
                    $_SESSION['fname'] = $first_name;

                    //Password is correct, redirect to welcome page
                    header("Location: welcome.php");
                    exit(); //Stop script after redirection
                } else {
                    //Incorrect password
                    $errors['password'] = "User password is invalid";
                }
            } else {
                //User does not exist (no rows returned for that email)
                $errors['email'] = "No user found with that email";
            }
        }
        //Close statement and connection
        $stmt->close();
        $conn->close();
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

</head>

<body>
    <!-- Welcome banner -->
    <header class="WelcomeHeader">
        <div class="h1-Banner">
            <h1>Hello.</h1>
            <h1>Welkom.</h1>
            <h1><span>Kunjani.</span></h1>
        </div>
        <h2>Let's make a deal, Mzanzi style!</h2>
    </header>

    <!-- Login form -->
    <form action="eLogin.php" method="post" onsubmit="return validateLogin()">
        <fieldset>
            <legend>Login</legend>

            <label for="email">Email:</label>
            <input type="text" name="email" id="email" value="<?php echo htmlspecialchars($email ?? ''); ?>">
            <span id="emailError" class="error"><?php echo $errors['email']; ?></span>

            <label for="password">Password:</label>
            <input type="password" name="password" id="password">
            <span id="passwordError" class="error"><?php echo $errors['password']; ?></span>

            <button type="submit">Login</button>
            <p>Don't have an account? <a href="eRegister.php">Register here</a></p>
        </fieldset>
    </form>

    <script src="script.js"></script>
</body>

</html>