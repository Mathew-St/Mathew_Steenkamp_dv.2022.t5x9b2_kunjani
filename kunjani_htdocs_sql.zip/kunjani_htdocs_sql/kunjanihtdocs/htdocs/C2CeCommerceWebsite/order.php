<?php
session_start();
require 'dbConnection.php';

$email = $_SESSION['email'] ?? null;
if (!$email) {
    header('Location: eLogin.php');
    exit();
}

//Check if user is a buyer
$buyer_id = null;   //Initialise id
$stmt = $conn->prepare("SELECT buyer_id FROM buyers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$buyer_result = $stmt->get_result();

if ($row = $buyer_result->fetch_assoc()) {
    $buyer_id = $row['buyer_id'];   //If found, store id
}
$stmt->close();

//Check if user is a seller
$seller_id = null;  //Initialise id
$stmt = $conn->prepare("SELECT seller_id FROM sellers WHERE user_id = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$seller_result = $stmt->get_result();

if ($row = $seller_result->fetch_assoc()) {
    $seller_id = $row['seller_id']; //If found, store id
}
$stmt->close();

//Initialise empty arrays for buyer and seller order data
$buyer_orders = [];
$seller_orders = [];

//Get buyer orders 
//group concat to concatenate product names in one order row (https://www.w3resource.com/mysql/aggregate-functions-and-grouping/aggregate-functions-and-grouping-group_concat.php)
if ($buyer_id) {
    $stmt = $conn->prepare("SELECT o.order_id, o.order_date, o.total_amount, GROUP_CONCAT(p.name SEPARATOR ', ') AS products,
        COUNT(oi.product_id) AS item_count FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN products p ON oi.product_id = p.product_id
        WHERE o.buyer_id = ?
        GROUP BY o.order_id, o.order_date, o.total_amount
        ORDER BY o.order_date DESC");
    $stmt->bind_param("i", $buyer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $buyer_orders = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

//Get seller orders 
//Joins buyers and users to access name and products
//Concate to join as one row (https://www.w3schools.com/sql/sql_join.asp)
if ($seller_id) {
    $stmt = $conn->prepare("SELECT o.order_id, o.order_date, CONCAT(u.fname, ' ', u.lname) AS buyer_name, p.name AS product_name, oi.price
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.order_id
        JOIN products p ON oi.product_id = p.product_id
        JOIN buyers b ON o.buyer_id = b.buyer_id
        JOIN users u ON b.user_id = u.email
        WHERE oi.seller_id = ?
        ORDER BY o.order_date DESC");
    $stmt->bind_param("i", $seller_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $seller_orders = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

//Display success message if order was just placed
$order_success = $_SESSION['order_success'] ?? null;
if ($order_success) {
    unset($_SESSION['order_success']);  //Clears success message after displaying
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

</head>
<body>
     <!-- Navigation bar-->
    <header>
        <a href="#"><img src="images/Kunji.png" class="logo" alt="Kunjani Logo"></a>
        <nav id="navigation-bar">
            <ul>
                <li><a href="welcome.php">Buy</a></li>
                <li><a href="sell.php">Sell</a></li>
                <li><a href="order.php" class="active">Orders</a></li>
            </ul>
            <span class="separator">|</span>
            <div class="right-menu-navbar">
                <ul>
                    <li><a href="eLogout.php">Logout</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main class="orders-container">
        <!--Displays any success messages-->
        <?php if ($order_success): ?>
            <div class="success-message">
                <?= htmlspecialchars($order_success) ?> <!--Prevent XSS attacks (https://www.php.net/manual/en/function.htmlspecialchars.php)-->
            </div>
        <?php endif; ?>

        <!--If buyer and has orders, display orders-->
        <?php if ($buyer_id && !empty($buyer_orders)): ?>
            <div class="orders-section">
                <h2>Orders Paid</h2>

                <!--Loop through buyer orders-->
                <?php foreach ($buyer_orders as $order): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <!--Display id and date as formatted type by using strtotime (https://www.php.net/manual/en/function.date.php)-->
                            <span class="order-id">Order #<?= htmlspecialchars($order['order_id']) ?></span>
                            <span class="order-date"><?= htmlspecialchars(date('F j, Y, g:i a', strtotime($order['order_date']))) ?></span>
                        </div>

                        <!--List of products and items-->
                        <div class="order-items">
                            <p><strong>Products:</strong> <?= htmlspecialchars($order['products']) ?></p>
                            <p><strong>Items:</strong> <?= htmlspecialchars($order['item_count']) ?></p>
                        </div>
                        <div class="order-total">
                            Total: R<?= number_format($order['total_amount'], 2) ?> <!--Source: https://www.php.net/manual/en/function.number-format.php -->
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        
        <!--BUYER with no orders-->
        <?php elseif ($buyer_id): ?>
            <div class="orders-section">
                <h2>Orders Paid</h2>
                <p>You haven't placed any orders yet.</p>
            </div>
        <?php endif; ?>

        <!--If seller and has orders, display orders-->
        <?php if ($seller_id && !empty($seller_orders)): ?>
            <div class="orders-section">
                <h2>Orders Sold</h2>
                <?php 

                // Group order items by order_id for display
                $grouped_orders = [];
                foreach ($seller_orders as $item) {
                    $order_id = $item['order_id'];
                    if (!isset($grouped_orders[$order_id])) {
                        $grouped_orders[$order_id] = [
                            'order_id' => $order_id,
                            'order_date' => $item['order_date'],
                            'buyer_name' => $item['buyer_name'],
                            'items' => []   //Holds order items in order
                        ];
                    }

                    //Append items to item list
                    $grouped_orders[$order_id]['items'][] = $item;
                }
                ?>
                
                <!--Loop through grouped orders-->
                <?php foreach ($grouped_orders as $order): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <!--Display id and date as formatted type by using strtotime (https://www.php.net/manual/en/function.date.php)-->
                            <span class="order-id">Order #<?= htmlspecialchars($order['order_id']) ?></span>
                            <span class="order-date"><?= htmlspecialchars(date('F j, Y, g:i a', strtotime($order['order_date']))) ?></span>
                        </div>

                        <!--Buyer full name from concat-->
                        <p><strong>Buyer:</strong> <?= htmlspecialchars($order['buyer_name']) ?></p>

                        <!--Loop through order items-->
                        <div class="order-items">
                            <?php foreach ($order['items'] as $item): ?>
                                <div class="order-item">
                                    <p><strong>Product:</strong> <?= htmlspecialchars($item['product_name']) ?></p>
                                    <p><strong>Price:</strong> R<?= number_format($item['price'], 2) ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        <!--SELLER with no orders-->
        <?php elseif ($seller_id): ?>
            <div class="orders-section">
                <h2>Orders Sold</h2>
                <p>You haven't sold any products yet.</p>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <div class="footer-content">
            <div class="column">
                <img class="logo" src="images/Kunji.png" alt="Kunjani Logo">
            </div>

            <div class="column">
                <h4>Contact</h4>
                <p><strong>Address:</strong> 64 Edward Road, Tygervalley, Cape Town</p>
                <p><strong>Phone:</strong> (+27) 021 445 9782</p>
                <p><strong>Hours:</strong> 09:00 - 17:00, Mon - Sat</p>
            </div>

            <div class="column">
                <h4>About</h4>
                <a href="#">About Kunjani</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
                <a href="#">Help</a>
            </div>

            <div class="column">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
                <div class="Payment-methods">
                    <p>Secured Payment Gateways</p>
                    <img src="images/pay/pay.png" alt="Payment methods">
                </div>

            </div>
        </div>

        <div class="copyright">
            <p>&copy; 2025 Kunjani - eCommerce by Mathew. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>
