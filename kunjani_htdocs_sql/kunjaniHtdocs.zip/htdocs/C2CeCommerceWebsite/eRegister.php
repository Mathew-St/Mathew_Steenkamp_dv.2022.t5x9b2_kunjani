<?php
//Initialise an array to store error messages (avoids having to use multiple variables in html)
$errors = [
    'fname' => '',
    'lname' => '',
    'email' => '',
    'password' => '',
];


//Retrieve input values
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = trim($_POST["fname"]);
    $lname = trim($_POST["lname"]);
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);
    //Hash password
    $hash = password_hash($password, PASSWORD_DEFAULT);

    //Check if empty: 
    //If empty - Update span tag in eRegister.html
    if (empty($fname)) {
        $errors['fname'] = "First name is required";
    }
    if (empty($lname)) {
        $errors['lname'] = "Last name is required";
    }
    if (empty($email)) {
        $errors['email'] = "Email is required";
    }
    if (empty($password)) {
        $errors['password'] = "Password is required";
    }

    //Check format:
    //Validate first name: Only letters, - and whitespace allowed
    if (!preg_match('/^[a-zA-Z\s-]+$/', $fname)) {  //Preg_match comapres string to regex
        //Update span tag in eRegister.html
        $errors['fname'] = "First name can only contain letters";
    }

    //Validate last name: Only letters, - and whitespace allowed
    if (!preg_match('/^[a-zA-Z\s-]+$/', $lname)) {
        //Update span tag in eRegister.html
        $errors['lname'] = "Last name can only contain letters";
    }

    //Validate email format (Built in function, no rejex required as in js)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        //Update span tag in eRegister.html
        $errors['email'] = "Invalid email format";
    }

    //Proceed with DB connection only if there are no errors
    if (empty(array_filter($errors))) {
        require 'dbConnection.php';

        //Check uniqueness of email: Can have people with same fname and lname
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);   //What is inserted (string)
        $stmt->execute(); //Execute the prepared statement
        //Get the result set of the prepared statement
        $check = $stmt->get_result();
        if ($check->num_rows > 0) {
            //Update span tag in eRegister.html
            $errors['email'] = "Email is already registered!";
        }

        //Proceed with registration only if there are no errors
        if (empty(array_filter($errors))) {
            //Registering a user:
            //Insert user into DB with prepared statement (prevent SQL injection)
            $stmt = $conn->prepare("INSERT INTO users (fname, lname, email, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $fname, $lname, $email, $hash);   //What is inserted (all strings)

            //Verify success of execution
            if ($stmt->execute() === TRUE) {
                echo "Registration successful!";
                //Redirect to login page after successful registration
                header("Location: eLogin.php");
                exit();
            } else {
                die("Error: " . $stmt->error);
            }

            //Close the prepared statement
            $stmt->close();
        }

        //Close the connection
        $conn->close();
    }
}
?>

<!-- HTML code -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">

</head>

<body>
    <!-- Welcome banner -->
    <header class="WelcomeHeader">
        <div class="h1-Banner">
            <h1>Hello.</h1>
            <h1>Welkom.</h1>
            <h1><span>Kunjani.</span></h1>
        </div>
        <h2>Let's make a deal, Mzanzi style!</h2>
    </header>

    <!-- Registration form -->
    <form action="eRegister.php" method="post" onsubmit="return validateRegistration()">
        <fieldset>
            <legend>Registration</legend>

            <label for="fname">First name:</label>
            <input type="text" name="fname" id="fname" placeholder="kun-ja'ni"
                value="<?php echo $fname ?? ''; ?>">    <!--For UX: retains input info - if empty, reverts to null-->
            <span id="fnameError" class="error"><?php echo $errors['fname']; ?></span>
            <!-- Span tag for error messages (JS on client and PHP on server)-->

            <label for="lname">Last name:</label>
            <input type="text" name="lname" id="lname" placeholder="ni ja-kun"
                value="<?php echo $lname ?? ''; ?>">    <!--For UX: retains input info - if empty, reverts to null-->
            <span id="lnameError" class="error"><?php echo $errors['lname']; ?></span>

            <label for="email">Email:</label>
            <input type="text" name="email" id="email" placeholder="kunjani-12@gmail.top.za"
                value="<?php echo htmlspecialchars($email ?? ''); ?>"> <!--Prevent Vulnerability to XSS-->
            <span id="emailError" class="error"><?php echo $errors['email']; ?></span>

            <!--Prevent XSS:-->
            <!--Value tag to prevent XSS attacks as email doesn't filter out special characters, e.g. <script>.gmail.com-->
            <!--$_POST fetches value, ?? fallsback to '' if nothing exists -->
            <!--Source: https://stackoverflow.com/questions/30562419/php-echo-htmlspecialchar-post-error-->

            <label for="password">Password:</label>
            <input type="password" name="password" id="password" placeholder="@Ex2mpl3">
            <span id="passwordError" class="error"><?php echo $errors['password']; ?></span>

            <button type="submit">Register</button>
            <p>Already have an account? <a href="eLogin.php">Login here</a></p>
        </fieldset>
    </form>

    <script src="script.js"></script>
</body>

</html>