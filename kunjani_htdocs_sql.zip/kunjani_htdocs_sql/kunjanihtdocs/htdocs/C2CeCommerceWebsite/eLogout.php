<?php
    //Initialise/start session
    session_start();

    //Logout:
    //Clear session variable
    session_unset();

    //Destroy session
    session_destroy();

    //Redirect
    header("Location: eLogin.php");
?>