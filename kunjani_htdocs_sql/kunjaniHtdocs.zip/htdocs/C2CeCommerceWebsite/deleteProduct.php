<?php
session_start();
require 'dbConnection.php';

//Verify ownership of product to seller
//By jjoining the products and sellers tables to link a product_id to a user's email
//Source: https://www.php.net/manual/en/mysqli-stmt.bind-param.php
$stmt = $conn->prepare("SELECT p.product_id FROM products p
                       JOIN sellers s ON p.seller_id = s.seller_id
                       WHERE p.product_id = ? AND s.user_id = ?");
$stmt->bind_param("is", $_GET['product_id'], $_SESSION['email']);
$stmt->execute();
$result = $stmt->get_result();

//Product does not exist or not owned by seller
if ($result->num_rows === 0) {
    $_SESSION['error'] = "Product not found or access denied";
    header("Location: sell.php");
    exit;
}

//Cascade deleted from dependent tables first
//Delete from cart first
$cart_delete = $conn->prepare("DELETE FROM cart WHERE product_id = ?");
$cart_delete->bind_param("i", $_GET['product_id']);
$cart_delete->execute();

//Then delete product
$delete = $conn->prepare("DELETE FROM products WHERE product_id = ?");
$delete->bind_param("i", $_GET['product_id']);
$delete->execute();

$_SESSION['success'] = "Product deleted successfully";
header("Location: sell.php");
exit;