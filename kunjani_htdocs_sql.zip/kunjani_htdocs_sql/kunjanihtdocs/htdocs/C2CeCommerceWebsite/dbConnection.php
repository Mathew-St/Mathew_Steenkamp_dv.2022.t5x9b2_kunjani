<?php
//For establishing general connections to db

//Database connection variables (change as see fit)
$host = "localhost";
$db_user = "root";
$db_password = "";  //Add password here
$db_name = "";  //Add db name here


//Create connection: mySQLI OO approach (W3Schools - Prepared statements)
$conn = new mysqli($host, $db_user, $db_password, $db_name);

//Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Set charset to avoid encoding issues
$conn->set_charset("utf8mb4");
