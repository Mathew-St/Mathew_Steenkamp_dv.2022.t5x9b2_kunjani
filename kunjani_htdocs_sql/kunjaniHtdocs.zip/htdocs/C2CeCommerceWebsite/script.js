//Client-side:
//Registration Script validation function
function validateRegistration() {
    //Get the input values
    let firstName = document.getElementById("fname").value.trim();
    let lastName = document.getElementById("lname").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();

    //Get the error messages
    let firstNameError = document.getElementById("fnameError");
    let lastNameError = document.getElementById("lnameError");
    let emailError = document.getElementById("emailError");
    let passwordError = document.getElementById("passwordError");

    //Initialise error messages
    firstNameError.innerHTML = "";
    lastNameError.innerHTML = "";
    emailError.innerHTML = "";
    passwordError.innerHTML = "";

    //Initialise validity
    let isValid = true;

    //Validate first names:
    //Validate empty first name field 
    if (firstName === "") {
        firstNameError.innerHTML = "First name is required";
        isValid = false;
    }
    //Validate first name type (letters, spaces and -)
    //Source: https://phppot.com/javascript/validate-name-javascript/
    else if (!/^[a-zA-Z\s-]+$/.test(firstName)) {
        firstNameError.innerHTML = "First name must contain letters only";
        isValid = false;
    }
    //Validate first name length
    else if (firstName.length < 2 || firstName.length > 30) {
        firstNameError.innerHTML = "First name must be between 2-30 characters";
        isValid = false;
    }

    //Validate last names:
    //Validate empty last name field
    if (lastName === "") {
        lastNameError.innerHTML = "Last name is required";
        isValid = false;
    }
    //Validate last name type (letters, spaces and -)
    else if (!/^[a-zA-Z\s-]+$/.test(lastName)) {
        lastNameError.innerHTML = "Last name must contain letters only";
        isValid = false;
    }
    //Validate last name length
    else if (lastName.length < 2 || lastName.length > 30) {
        lastNameError.innerHTML = "Last name must be between 2-30 characters";
        isValid = false;
    }

    //Validate email:
    //Validate empty email field
    if (email === "") {
        emailError.innerHTML = "Email is required";
        isValid = false;
    }
    //Validate email format (Local = chars except space and @s, @, Domain = chars except space and @s, ., Top-level domain = no spaces or @s)
    //Source: https://sendbridge.com/tutorials/regular-expression-regex-for-email-validation
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        emailError.innerHTML = "Email format is invalid";
        isValid = false;
    }

    //Validate password:
    //Validate empty password
    if (password === "") {
        passwordError.innerHTML = "Password is required";
        isValid = false;
    }
    //Validate password length
    else if (password.length < 8) {
        passwordError.innerHTML = "Password must be 8 characters or more";
        isValid = false;
    }

    //All validation passed
    return isValid;

}

//Login Script validation function
function validateLogin(){
    //Get the input values
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value.trim();

    //Get the error messages
    let emailError = document.getElementById("emailError");
    let passwordError = document.getElementById("passwordError");

    //Initialise error messages
    emailError.innerHTML = "";
    passwordError.innerHTML = "";

    //Initialise validity
    let isValid = true;

    //Validate email:
    //Validate empty email field
    if (email === "") {
        emailError.innerHTML = "Email is required";
        isValid = false;
    }
    //Validate email format (Local = chars except space and @s, @, Domain = chars except space and @s, ., Top-level domain = no spaces or @s)
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        emailError.innerHTML = "Email format is invalid";
        isValid = false;
    }

    //Validate password:
    //Validate empty password
    if (password === "") {
        passwordError.innerHTML = "Password is required";
        isValid = false;
    }
    //Validate password length
    else if (password.length < 8) {
        passwordError.innerHTML = "Password must be 8 characters or more";
        isValid = false;
    }

    //All validation passed
    return isValid;
}