<?php
require 'dbConnection.php'; //DB connection file

//Null Coalescing Operator ( https://www.php.net/manual/en/language.operators.comparison.php#language.operators.comparison.coalesce)
$email = $_SESSION['email'] ?? null;   //Retrieve user email from session, if not set, it will be null (=Proves logged in)

//Check if the form is submitted and user is logged in
if ($_SERVER["REQUEST_METHOD"] === "POST" && $email) { 
    //Dynamically fetch seller_id using the user's email
    $stmt = $conn->prepare("SELECT seller_id FROM sellers WHERE user_id = ?");  //Get PK of seller using user_id
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $seller = $result->fetch_assoc();       //Fetch seller's data as an associative array (set of key-value pairs) (https://www.php.net/manual/en/mysqli-result.fetch-assoc.php)
    $stmt->close();

    //Seller does not exist
    if (!$seller) {
        die("Seller not found. Please register as a seller first.");    //Stops script if seller not found
    }

    //Retrieve seller_id from the database
    $seller_id = $seller['seller_id']; 

    //Get form info
    $category = $_POST['category']; //Get product category from form
    $name = $_POST['name']; //Get product name from form        
    $description = $_POST['description']; //Get product description from form
    $price = $_POST['price']; //Get product price from form        

    //Upload product image file
    $target_dir = "uploads/products/"; //Directory where the product image will be uploaded
    $target_file = $target_dir . uniqid() . "_" . basename($_FILES["image"]["name"]); //Full path to the uploaded file with a unique ID to avoid overwriting files (https://www.php.net/manual/en/function.basename.php)

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) { //Move the uploaded file to the target directory (https://www.php.net/manual/en/function.move-uploaded-file.php)
        //Insert product using seller_id from database
        $stmt = $conn->prepare("INSERT INTO products (seller_id, category, name, description, price, image) VALUES (?, ?, ?, ?, ?, ?)"); //Statement to insert product details
        $stmt->bind_param("isssds", $seller_id, $category, $name, $description, $price, $target_file); //Bind parameters
        $stmt->execute();
        $stmt->close();

        //Redirect to the sell page after successful product addition
        header("Location: sell.php");
        exit();
    } else {
        $error = "File upload failed";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add ProductPopup</title>
    <link rel="stylesheet" href="styles2.css?v=<?php echo time(); ?>"> <!--General styles -->
</head>

<body>
    <div class="product-PopupBackdrop" id="productPopupBackdrop"></div>
    <div class="product-PopupContainer" id="productPopupContainer">
        <form class="product-form" method="POST" enctype="multipart/form-data" action=""> <!--Multipart form to handle file uploads (https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#enctype)-->
            <fieldset>
                <legend>Add New Product</legend>

                <?php if (isset($error)): ?>
                    <div class="error-message"><?= htmlspecialchars($error) ?></div>    <!--Display error message if file upload failed -->
                <?php endif; ?>

                <label for="name">Product Name</label>
                <input type="text" name="name" maxlength="100" required>

                <label for="category">Select Category</label>
                <select name="category" id="category" required>
                    <option value="Health & Lifestyle">Health & Lifestyle</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Home & Braai">Home & Braai</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Garden & Outdoor">Garden & Outdoor</option>
                    <option value="Lekker Food">Lekker Food</option>
                    <option value="Sports & Fitness">Sports & Fitness</option>
                </select>

                <label for="description">Description</label>
                <input type="text" name="description" maxlength="255" required>

                <label for="price">Price (R)</label>
                <input type="number" name="price" step="0.01" min="0" required> <!--Step allows decimal values, min = price is not negative -->

                <label for="image">Product Image</label>
                <input type="file" name="image" accept="image/*" required>

                <button type="submit">Add Product</button>
                <button type="button" class="back-button" onclick="hideProductPopup()">Cancel</button>
            </fieldset>
        </form>
    </div>
</body>

</html>